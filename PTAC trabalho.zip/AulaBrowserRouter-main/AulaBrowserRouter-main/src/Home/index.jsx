import {useState} from "react";
import Header  from "../Header";
import ListaProduto from "../ListaProdutos";
import Carousel from "../Carrosel";
import Footer from "../Footer";

export default function Produtos() { 
    const [ListaProdutos] = useState([
      { id: 100, nome: 'O Rato', preco:'R$35,50', imagem:'src/Imagens/rato.png', artista:'Julia Garcia', desconto: "15%"},
      { id: 200, nome: 'Café', preco:'R$20,00', imagem:'src/Imagens/café.png', artista:'Julia Garcia', desconto: "20%"},
      { id: 300, nome: 'Flor Roxa', preco:'R$4,25',imagem:'src/Imagens/florsolitaria.png', artista:'Julia Garcia', desconto: "15%"},
      { id: 400, nome: 'Flores', preco:'R$9,99', imagem:'src/Imagens/flower.png', artista:'Julia Garcia', desconto: "15%"},
      { id: 500, nome: 'Doguinho', preco:'R$24,99', imagem:'src/Imagens/keila.png', artista:'Julia Garcia', desconto: "50%"},        
    ]);
    return (
      <>
      <Header/>
      <br/>
      <h1 className='meus'>Originais</h1>
        <Carousel/>
        <br/>
          <ListaProduto lista={ListaProdutos}/>
          <Footer/>
    </>
     );
    }