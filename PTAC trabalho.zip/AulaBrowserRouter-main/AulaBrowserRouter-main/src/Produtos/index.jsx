import {useState} from "react";
import Header  from "../Header";
import ListaProduto from "../ListaProdutos";
import Carousel from "../Carrosel";
import Footer from "../Footer";

export default function Produtos() { 
    const [ListaProdutos] = useState([
      { id: 100, nome: 'O Rato', preco:'R$35,50', imagem:'src/Imagens/rato.png', artista:'Julia Garcia', desconto: "15%"},
      { id: 200, nome: 'Café', preco:'R$20,00', imagem:'src/Imagens/café.png', artista:'Julia Garcia', desconto: "20%"},
      { id: 300, nome: 'Flor Roxa', preco:'R$4,25',imagem:'src/Imagens/florsolitaria.png', artista:'Julia Garcia', desconto: "15%"},
      { id: 400, nome: 'Flores', preco:'R$9,99', imagem:'src/Imagens/flower.png', artista:'Julia Garcia', desconto: "15%"},
      { id: 500, nome: 'Doguinho', preco:'R$24,99', imagem:'src/Imagens/keila.png', artista:'Julia Garcia', desconto: "50%"},    
      { id: 600, nome: 'Água-Viva', preco:'R$24,99', imagem:'src/Imagens/aguaviva.webp', artista:'Desconhecido', desconto: "10%"},
      { id: 700, nome: 'Charmander', preco:'R$25,00', imagem:'src/Imagens/char.png', artista:'Desconhecido', desconto: "50%"},
      { id: 800, nome: 'Dragão', preco:'R$10,00',imagem:'src/Imagens/dragao.jpg', artista:'Desconhecido', desconto: "20%"},
      { id: 900, nome: 'Freddy', preco:'R$34,80', imagem:'src/Imagens/frederico.png', artista:'Desconhecido', desconto: "5%"},
      { id: 110, nome: 'Homem', preco:'R$24,00', imagem:'src/Imagens/homem.png', artista:'Desconhecido', desconto: "10%"},  
      { id: 120, nome: 'Kirby', preco:'R$35,50', imagem:'src/Imagens/kirby.jpg', artista:'Desconhecido', desconto: "50%"},
      { id: 130, nome: 'Mangle', preco:'R$12,55', imagem:'src/Imagens/lego.png', artista:'Desconhecido', desconto: "30%"},
      { id: 140, nome: 'Orca', preco:'R$4,00',imagem:'src/Imagens/orca.webp', artista:'Desconhecido', desconto: "90%%"},
      { id: 150, nome: 'Vaso de Planta', preco:'R$19,99', imagem:'src/Imagens/planta.avif', artista:'Desconhecido', desconto: "10%"},
      { id: 160, nome: 'Saiko', preco:'R$80,40', imagem:'src/Imagens/saiko.png', artista:'Desconhecido', desconto: "35%"},  
      { id: 170, nome: 'Garota de Cabelo Rosa', preco:'R$31,90', imagem:'src/Imagens/1.png', artista:'Desconhecido', desconto: "0%"},    
      { id: 180, nome: 'Luffy', preco:'R$30.000,00', imagem:'src/Imagens/2.jpg', artista:'Desconhecido', desconto: "0%"},
      { id: 190, nome: 'Pysduck', preco:'R$60,09', imagem:'src/Imagens/3.png', artista:'Desconhecido', desconto: "0%"},
      { id: 210, nome: 'Hatsune Miku', preco:'R$60,00', imagem:'src/Imagens/4.jpg', artista:'Desconhecido', desconto: "0%"},
      { id: 220, nome: 'Gumi', preco:'R$50,00', imagem:'src/Imagens/6.jpg', artista:'Desconhecido', desconto: "0%"},
      { id: 230, nome: 'Eevee', preco:'R$70,00', imagem:'src/Imagens/sla.png', artista:'Desconhecido', desconto: "0%"},
      { id: 240, nome: 'Gato no Sol', preco:'R$20,00', imagem:'src/Imagens/cat.jpg', artista:'Desconhecido', desconto: "0%"},
    ]);
    return (
      <>
      <Header/>
      <br/>
      <h1 className='meus'>Tudos</h1>
        <Carousel/>
        <br/>
          <ListaProduto lista={ListaProdutos}/>
          <Footer/>
    </>
     );
    }